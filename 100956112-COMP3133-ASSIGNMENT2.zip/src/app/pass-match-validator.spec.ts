import { PassMatchValidator } from './pass-match-validator';

describe('PassMatchValidator', () => {
  it('should create an instance', () => {
    expect(new PassMatchValidator()).toBeTruthy();
  });
});
